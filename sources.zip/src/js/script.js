import * as nFunctions from "./modules/functions.js";
//nFunctions.nCustomCursor();
nFunctions.nWhatAscreen();
//nFunctions.nHeader();
//nFunctions.isWebp();
nFunctions.dynamicAdapt();
nFunctions.nLazyLoading();
nFunctions.nSelect();
//nFunctions.nSpollers();

document.addEventListener('DOMContentLoaded', function() {
   
   // website color
   window.addEventListener("load", () => {
      const html = document.documentElement;

      function applyTheme() {
         const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
         
         // Adding a class only for dark theme
         if (isDark) {
            html.classList.add('dark');
         } else {
            html.classList.remove('dark');
         }
      }

      // Initial application of the theme
      applyTheme();

      // We are monitoring changes to the system theme
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);
   });

   // Language selection
   const selector = document.querySelector('.language-selector');
   const currentBtn = document.querySelector('.language-current');
   const languageList = document.querySelector('.language-list');

   if (!selector || !currentBtn) return;

   // Open/close on click
   currentBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      selector.classList.toggle('active');
   });

   // Click on link + close
   languageList.addEventListener('click', (e) => {
      const link = e.target.closest('a');
      if (link) {
         // You can add a visual effect before the transition if needed.
         selector.classList.remove('active');
         // The transition occurs automatically by href
      }
   });

   // Close when clicking outside the menu
   document.addEventListener('click', (e) => {
      if (!selector.contains(e.target)) {
         selector.classList.remove('active');
      }
   });

   // Close by Esc
   document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && selector.classList.contains('active')) {
         selector.classList.remove('active');
      }
   });


   // Headers buttons
   const headerButtons = document.querySelector('.header__buttons');
   if (headerButtons) {
      headerButtons.classList.remove('hidden');
   }
});

//nFunctions.nPopUp();
//nFunctions.backToTop();